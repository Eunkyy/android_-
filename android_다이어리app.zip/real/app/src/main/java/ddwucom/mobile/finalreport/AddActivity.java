package ddwucom.mobile.finalreport;

import static java.lang.Integer.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;
import java.util.Random;

public class AddActivity extends AppCompatActivity {
    TextView etDate;
    EditText etWeather;
    EditText etTitle;
    EditText etContent;
    EditText etPlace;
    EditText etFeeling;
    String num;
    DiaryDBManager diaryDBManager;
    DiaryDBHelper diaryDBHelper;
    CalendarView calendarView;
    int flag=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        etDate = findViewById(R.id.date0);
        etWeather = findViewById(R.id.weather0);
        etTitle = findViewById(R.id.title0);
        etContent = findViewById(R.id.content0);
        etPlace = findViewById(R.id.place0);
        etFeeling = findViewById(R.id.feeling0);

        Random random = new Random();
        num = num.valueOf(random.nextInt(9));
        num = num.valueOf(random.nextInt(9));

        int[] images = {R.mipmap.img0, R.mipmap.img1, R.mipmap.img2, R.mipmap.img2, R.mipmap.img4, R.mipmap.img5, R.mipmap.img6, R.mipmap.img7, R.mipmap.img8, R.mipmap.img9, R.mipmap.img3};

        ImageView imageView = findViewById(R.id.add_img);
        imageView.setImageResource(images[parseInt(num)]);
        calendarView = (CalendarView)findViewById(R.id.calendar);
        calendarView.setVisibility(View.INVISIBLE);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange( CalendarView view, int year, int month, int dayOfMonth) {
                etDate.setText(String.format("%d/%d/%d",year,month+1,dayOfMonth));
            }
        });
        diaryDBManager = new DiaryDBManager(this);
    }


    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_add:
                if (etDate.getText().toString().isEmpty() || etTitle.getText().toString().isEmpty() || etFeeling.getText().toString().isEmpty()) {
                    Toast.makeText(this, "날짜, 제목, 기분은 필수 입력사항입니다.", Toast.LENGTH_SHORT).show();
                }
                else {
                    ListData ld = new ListData(etDate.getText().toString(), etWeather.getText().toString(), etTitle.getText().toString(), etContent.getText().toString(), etPlace.getText().toString(), etFeeling.getText().toString(), parseInt(num));
                    boolean result = diaryDBManager.addNewDiary(ld);
                    ld.setNum(parseInt(num));

                    if (result) {    // 정상수행에 따른 처리
                        Intent resultIntent = new Intent();
                        resultIntent.putExtra("date", etDate.getText().toString());
                        setResult(RESULT_OK, resultIntent);
                        finish();
                    } else {        // 이상에 따른 처리
                        Toast.makeText(this, "추가X", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
                break;
            case R.id.btn_cancel:
                finish();
                break;
            case R.id.chip_cal:
                calendarView.setVisibility(View.VISIBLE);
                break;
            case R.id.chip_cal2:
                calendarView.setVisibility(View.INVISIBLE);
                break;
        }
    }
}