package ddwucom.mobile.finalreport;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DiaryDBManager {

    DiaryDBHelper diaryDBHelper = null;
    Cursor cursor = null;
    ArrayList<ListData> listData;

    public DiaryDBManager(Context context) {
        diaryDBHelper = new DiaryDBHelper(context);
        listData = new ArrayList<ListData>();
    }

    public ArrayList<ListData> getDiaryList() {
        return listData;
    }

    public ArrayList<ListData> getAllDiary() {
        listData.clear();

        SQLiteDatabase db = diaryDBHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + DiaryDBHelper.TABLE_NAME, null);

        while(cursor.moveToNext()) {
            long id = cursor.getInt(cursor.getColumnIndex(DiaryDBHelper.COL_ID));
            String date = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_DATE));
            String weather = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_WTR));
            String title = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_TITLE));
            String content = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_CTT));
            String place = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_PLC));
            String feeling = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_FEEL));
            int num = cursor.getInt(cursor.getColumnIndex(DiaryDBHelper.COL_NUM));
            listData.add ( new ListData(id, date, weather, title, content, place, feeling, num) );
        }

        cursor.close();
        diaryDBHelper.close();
        return listData;
    }

    public String getsearchDiary(String key) {
        String[] columns = {"date", "title", "feeling"};
        SQLiteDatabase db = diaryDBHelper.getReadableDatabase();
        Cursor cursor = db.query(DiaryDBHelper.TABLE_NAME, null,"date=?", new String[]{key}, null, null, null, null);

        String result = "";
        while(cursor.moveToNext()) {
            long id = cursor.getInt(cursor.getColumnIndex(DiaryDBHelper.COL_ID));
            String date = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_DATE));
            String weather = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_WTR));
            String title = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_TITLE));
            String content = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_CTT));
            String place = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_PLC));
            String feeling = cursor.getString(cursor.getColumnIndex(DiaryDBHelper.COL_FEEL));
            int num = cursor.getInt(cursor.getColumnIndex(DiaryDBHelper.COL_NUM));
            ListData listData = new ListData(date, weather, title, content, place, feeling, num); //객체 생성.
            result += listData.toString() + "\n";
        }

        cursor.close();
        diaryDBHelper.close();
        return result;
    }

    public boolean addNewDiary(ListData newDiary) {
        SQLiteDatabase db = diaryDBHelper.getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put(DiaryDBHelper.COL_DATE, newDiary.getDate());
        value.put(DiaryDBHelper.COL_WTR, newDiary.getWeather());
        value.put(DiaryDBHelper.COL_TITLE, newDiary.getTitle());
        value.put(DiaryDBHelper.COL_CTT, newDiary.getContent());
        value.put(DiaryDBHelper.COL_PLC, newDiary.getPlace());
        value.put(DiaryDBHelper.COL_FEEL, newDiary.getFeeling());

//      insert 메소드를 사용할 경우 데이터 삽입이 정상적으로 이루어질 경우 1 이상, 이상이 있을 경우 0 반환 확인 가능
        long result = db.insert(DiaryDBHelper.TABLE_NAME, null, value);
        diaryDBHelper.close();
        if (result > 0) return true;
        return false;
    }

    public boolean modifyDiary(ListData diary) {
        SQLiteDatabase sqLiteDatabase = diaryDBHelper.getWritableDatabase();
        ContentValues row = new ContentValues();
        row.put(DiaryDBHelper.COL_DATE, diary.getDate());
        row.put(DiaryDBHelper.COL_WTR, diary.getWeather());
        row.put(DiaryDBHelper.COL_TITLE, diary.getTitle());
        row.put(DiaryDBHelper.COL_CTT, diary.getContent());
        row.put(DiaryDBHelper.COL_PLC, diary.getPlace());
        row.put(DiaryDBHelper.COL_FEEL, diary.getFeeling());
        String whereClause = DiaryDBHelper.COL_ID + "=?";
        String[] whereArgs = new String[] { String.valueOf(diary.get_id()) };
        int result = sqLiteDatabase.update(DiaryDBHelper.TABLE_NAME, row, whereClause, whereArgs);
        diaryDBHelper.close();
        if (result > 0) return true;
        return false;
    }

    public boolean removeDiary(long id) {
        SQLiteDatabase sqLiteDatabase = diaryDBHelper.getWritableDatabase();
        String whereClause = DiaryDBHelper.COL_ID + "=?";
        String[] whereArgs = new String[] { String.valueOf(id) };
        int result = sqLiteDatabase.delete(DiaryDBHelper.TABLE_NAME, whereClause,whereArgs);
        diaryDBHelper.close();
        if (result > 0) return true;
        return false;
    }

    //    close 수행
    public void close() {
        if (diaryDBHelper != null) diaryDBHelper.close();
        if (cursor != null) cursor.close();
    };
}