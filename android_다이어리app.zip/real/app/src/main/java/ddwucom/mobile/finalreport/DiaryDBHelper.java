package ddwucom.mobile.finalreport;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DiaryDBHelper extends SQLiteOpenHelper {
    final static String TAG = "DiaryDBHelper";

    final static String DB_NAME = "diary.db";
    public final static String TABLE_NAME = "diary_table";

    public final static String COL_ID = "_id";
    public final static String COL_DATE = "date";
    public final static String COL_WTR = "weather";
    public final static String COL_TITLE = "title";
    public final static String COL_CTT = "content";
    public final static String COL_PLC = "place";
    public final static String COL_FEEL = "feeling";
    public final static String COL_NUM = "num";

    public DiaryDBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " integer primary key autoincrement, " +
                COL_DATE + " TEXT, " +  COL_WTR + " TEXT, " +  COL_TITLE + " TEXT, " +  COL_CTT + " TEXT, " +  COL_PLC + " TEXT, " + COL_FEEL + " TEXT, " + COL_NUM + " integer)";
        Log.d(TAG, sql);
        db.execSQL(sql);

        insertSample(db);       // 샘플이 필요할 경우 추가
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVer, int newVer) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    private void insertSample(SQLiteDatabase db) {
        db.execSQL("insert into " + TABLE_NAME + " values (null, '2020/01/18', '맑음', '졸업식', '오늘은 학교에서 졸업식을 했다. 속상했다.', '한빛고', '슬픔', '2');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '2020/08/02', '햇빛 쨍쨍', '내 생일', '오늘은 내 생일이라 재밌게 놀았다.', '건대', '즐거움', '5');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '2020/12/31', '눈이 옴', '20년 마지막 날', '내일이면 내가 21살이라니..시간 참 빠르다.', '집', '설렘', '6');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '2021/06/17', '비가 내림', '종강', '오늘은 2-1학기 종강을 했다.', '동덕여대', '기쁨', '8');");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '2022/05/04', '맑고 선선함', '에버랜드', '동생이랑 에버랜드에 갔다.', '용인 에버랜드', '매우 즐거움', '10');");
    }
}