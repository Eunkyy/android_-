package ddwucom.mobile.finalreport;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<ListData> dataList;
    private LayoutInflater layoutInflater;

    public MyAdapter(Context context, int layout, ArrayList<ListData> myDataList){
        this.context = context;
        this.layout = layout;
        this.dataList = myDataList;
        layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return dataList.size();
    }

    @Override
    public ListData getItem(int pos) {
        return dataList.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return dataList.get(pos).get_id();
    }

    public View getView(int pos, View convertView, ViewGroup viewGroup) {
        final int position = pos;
        ViewHolder viewHolder;
        int[] images = {R.mipmap.img0, R.mipmap.img1, R.mipmap.img2, R.mipmap.img3, R.mipmap.img4, R.mipmap.img5, R.mipmap.img6, R.mipmap.img7, R.mipmap.img8, R.mipmap.img9, R.mipmap.img3};
        int num;
        if(getItem(pos).getNum() == 0) {
            Random random = new Random();
            num = random.nextInt(9);
        }
        else {
            num = getItem(pos).getNum();
        }
        if (convertView == null) {
            convertView = layoutInflater.inflate(layout, viewGroup, false);

            viewHolder = new ViewHolder();
            viewHolder.img = convertView.findViewById(R.id.list_img);
            viewHolder.img.setImageResource(images[num]);
            dataList.get(pos).setNum(num);
            viewHolder.title = convertView.findViewById(R.id.title_list);
            viewHolder.date = convertView.findViewById(R.id.date);
            viewHolder.feeling = convertView.findViewById(R.id.feeling);

            convertView.setTag(viewHolder);

        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.title.setText( dataList.get(position).getTitle() );
        viewHolder.date.setText( dataList.get(position).getDate() );
        viewHolder.feeling.setText( dataList.get(position).getFeeling() );

        return convertView;
    }

    static class ViewHolder {
        ImageView img;
        TextView title;
        TextView date;
        TextView feeling;
    }

}