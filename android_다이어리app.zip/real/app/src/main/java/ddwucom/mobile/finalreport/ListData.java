package ddwucom.mobile.finalreport;
import java.io.Serializable;

public class ListData implements Serializable{
    private long _id;
    private String date;
    private String weather;
    private String title;
    private String content;
    private String place;
    private String feeling;
    int num;

    public ListData(String date, String weather, String title, String content, String place, String feeling, int num) {
        this.date = date;
        this.weather = weather;
        this.title = title;
        this.content = content;
        this.place = place;
        this.feeling = feeling;
        this.num = num;
    }

    public ListData(long _id, String date, String weather, String title, String content, String place, String feeling, int num) {
        this._id = _id;
        this.date = date;
        this.weather = weather;
        this.title = title;
        this.content = content;
        this.place = place;
        this.feeling = feeling;
        this.num = num;
    }

    public void set_id(long _id) {
        this._id = _id;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setWeather(String weather) { this.weather = weather; }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setContent(String content) { this.content = content; }

    public void setPlace(String place) {
        this.place = place;
    }

    public void setFeeling(String feeling) {
        this.feeling = feeling;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public long get_id() { return _id; }

    public String getDate() {
        return date;
    }

    public String getWeather() {
        return weather;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() { return content; }

    public String getPlace() {
        return place;
    }

    public String getFeeling() {
        return feeling;
    }

    public int getNum() { return num; }

    @Override
    public String toString() {
        return "ListData{" +
                "_id=" + _id +
                ", date='" + date + '\'' +
                ", weather='" + weather + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                ", place='" + place + '\'' +
                ", feeling='" + feeling + '\'' +
                ", num=" + num +
                '}';
    }
}