package ddwucom.mobile.finalreport;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class SearchActivity extends AppCompatActivity {
    EditText etKey;
    TextView etRslt;

    DiaryDBManager diaryDBManager;
    DiaryDBHelper diaryDBHelper;
    String[] columns = {"_id", "date", "weather", "title", "content", "place", "feeling"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        etKey = findViewById(R.id.etKey);
        etRslt = findViewById(R.id.search_rslt);

        diaryDBManager = new DiaryDBManager(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_srch:
                String key = etKey.getText().toString();
                String rslt = diaryDBManager.getsearchDiary(key);

                etRslt.setText(rslt);
                break;
            case R.id.btn_exit:   // 취소에 따른 처리
                finish();
                break;
        }
    }
}