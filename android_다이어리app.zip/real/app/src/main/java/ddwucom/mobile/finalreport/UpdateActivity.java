package ddwucom.mobile.finalreport;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {
    ListData listData;
    TextView etDate;
    EditText etWeather;
    EditText etTitle;
    EditText etContent;
    EditText etPlace;
    EditText etFeeling;
    int num;
    DiaryDBManager diaryDBManager;
    CalendarView calendarView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        listData = (ListData) getIntent().getSerializableExtra("listData");

        etDate = findViewById(R.id.date2);
        etWeather = findViewById(R.id.weather2);
        etTitle = findViewById(R.id.title2);
        etContent = findViewById(R.id.content2);
        etPlace = findViewById(R.id.place2);
        etFeeling = findViewById(R.id.feeling2);

        etDate.setText(listData.getDate());
        etWeather.setText(listData.getWeather());
        etTitle.setText(listData.getTitle());
        etContent.setText(listData.getContent());
        etPlace.setText(listData.getPlace());
        etFeeling.setText(listData.getFeeling());

        num = listData.getNum();
        int[] images = {R.mipmap.img0, R.mipmap.img1, R.mipmap.img2, R.mipmap.img3, R.mipmap.img4, R.mipmap.img5, R.mipmap.img6, R.mipmap.img7, R.mipmap.img8, R.mipmap.img9, R.mipmap.img3};

        ImageView imageView = findViewById(R.id.upd_img);
        imageView.setImageResource(images[num]);
        calendarView = (CalendarView)findViewById(R.id.calendar2);
        calendarView.setVisibility(View.INVISIBLE);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange( CalendarView view, int year, int month, int dayOfMonth) {
                etDate.setText(String.format("%d/%d/%d",year,month+1,dayOfMonth));
            }
        });
        diaryDBManager = new DiaryDBManager(this);
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btn_udt:
                listData.setDate(etDate.getText().toString());
                listData.setWeather(etWeather.getText().toString());
                listData.setTitle(etTitle.getText().toString());
                listData.setContent(etContent.getText().toString());
                listData.setPlace(etPlace.getText().toString());
                listData.setFeeling(etFeeling.getText().toString());

                if(diaryDBManager.modifyDiary(listData)) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("num", num);
                    setResult(RESULT_OK, resultIntent);
                    finish();
                }
                else {
                    setResult(RESULT_CANCELED);
                    finish();
                }
                break;
            case R.id.btn_cancel2:
                setResult(RESULT_CANCELED);
                finish();
                break;
            case R.id.chip_cal3:
                calendarView.setVisibility(View.VISIBLE);
                break;
            case R.id.chip_cal4:
                calendarView.setVisibility(View.INVISIBLE);
                break;
        }

    }
}